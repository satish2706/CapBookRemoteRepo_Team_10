package com.cg.capbook.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capbook.beans.Persons;

@Controller
public class URIController {
	Persons persons;
	@RequestMapping(value= {"/","/index"})
	public String getIndexPage() {
		return "index";
	}
	
	@ModelAttribute
	public Persons getPersons() {
		persons=new Persons();
		return persons;
	}
	
}