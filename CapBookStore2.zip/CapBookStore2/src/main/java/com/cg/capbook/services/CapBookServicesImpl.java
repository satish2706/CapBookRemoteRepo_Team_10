package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.daoservices.CapBookDAOServices;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices{
	@Autowired
	CapBookDAOServices capBookDAOServices;
	@Override
	public String acceptPersonDetails(Persons persons) {
		//person.setVerificationCode((long) ((Math.random()*999999)-1));
		
		persons = capBookDAOServices.save(persons);
		return persons.getPersonEmailId();
	}
	@Override
	public Persons getPersonDetails(String personEmailId) throws Exception {
		Persons persons=capBookDAOServices.findById(personEmailId).orElseThrow(()-> new Exception());
		return persons;
	}

}
