package com.cg.capbook.daoservices;

import java.io.IOException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.multipart.MultipartFile;

public class ProfilePictureDAOSrevices implements ProfilePictureDAO{
	private JdbcTemplate jdbcTemplate;
	public void ImageDao(DataSource dataSource) {
			jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public int inserRecords(MultipartFile photo) throws IOException {
		{

			byte[] photoBytes = photo.getBytes();

			String sql = "INSERT INTO Persons(PHOTO) VALUES (?)";

			return jdbcTemplate.update(sql, new Object[] {photoBytes});
		}
	}
	

}
