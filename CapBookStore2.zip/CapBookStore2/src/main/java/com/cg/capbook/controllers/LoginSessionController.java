package com.cg.capbook.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.services.CapBookServices;
@SessionAttributes("personEmailId")
@Controller
public class LoginSessionController {
	@Autowired
	private CapBookServices capBookServices;
	@RequestMapping("/personLogin")
	public ModelAndView completeRegistrationUsingGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword,ModelMap model) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(capBookServices.checkPassword(personPassword, persons.getPersonPassword())==true) {
			model.put("personEmailId", personEmailId);
			return new ModelAndView("profilePage","persons",persons);}
		else
			return new ModelAndView("index","persons",persons);
	}
}
