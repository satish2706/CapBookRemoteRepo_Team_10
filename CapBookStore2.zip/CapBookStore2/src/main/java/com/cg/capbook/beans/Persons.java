/*
 * package com.cg.capbook.beans;
 * 
 * import javax.persistence.Entity; import javax.persistence.Id;
 * 
 * @Entity public class Persons {
 * 
 * @Id private String personEmailId; private String personFirstName; private
 * String personLastName; private String personPassword; private String
 * securityAnswer; private String repeatPersonPassword; private String
 * dateOfBirthOfPerson; public String getPersonFirstName() { return
 * personFirstName; } public void setPersonFirstName(String personFirstName) {
 * this.personFirstName = personFirstName; } public String getPersonLastName() {
 * return personLastName; } public void setPersonLastName(String personLastName)
 * { this.personLastName = personLastName; } public String getPersonEmailId() {
 * return personEmailId; } public void setPersonEmailId(String personEmailId) {
 * this.personEmailId = personEmailId; } public String getPersonPassword() {
 * return personPassword; } public void setPersonPassword(String personPassword)
 * { this.personPassword = personPassword; } public String
 * getRepeatPersonPassword() { return repeatPersonPassword; } public void
 * setRepeatPersonPassword(String repeatPersonPassword) {
 * this.repeatPersonPassword = repeatPersonPassword; } public String
 * getDateOfBirthOfPerson() { return dateOfBirthOfPerson; } public void
 * setDateOfBirthOfPerson(String dateOfBirthOfPerson) { this.dateOfBirthOfPerson
 * = dateOfBirthOfPerson; } public String getSecurityAnswer() { return
 * securityAnswer; } public void setSecurityAnswer(String securityAnswer) {
 * this.securityAnswer = securityAnswer; }
 * 
 * 
 * 
 * public Persons() {}
 * 
 * public Persons(String personEmailId, String personFirstName, String
 * personLastName, String personPassword, String securityAnswer, String
 * repeatPersonPassword, String dateOfBirthOfPerson) { super();
 * this.personEmailId = personEmailId; this.personFirstName = personFirstName;
 * this.personLastName = personLastName; this.personPassword = personPassword;
 * this.securityAnswer = securityAnswer; this.repeatPersonPassword =
 * repeatPersonPassword; this.dateOfBirthOfPerson = dateOfBirthOfPerson; }
 * public Persons(String personFirstName, String personLastName, String
 * personPassword, String securityAnswer, String repeatPersonPassword, String
 * dateOfBirthOfPerson) { super(); this.personFirstName = personFirstName;
 * this.personLastName = personLastName; this.personPassword = personPassword;
 * this.securityAnswer = securityAnswer; this.repeatPersonPassword =
 * repeatPersonPassword; this.dateOfBirthOfPerson = dateOfBirthOfPerson; }
 * 
 * @Override public String toString() { return "Persons [personEmailId=" +
 * personEmailId + ", personFirstName=" + personFirstName + ", personLastName="
 * + personLastName + ", personPassword=" + personPassword + ", securityAnswer="
 * + securityAnswer + ", repeatPersonPassword=" + repeatPersonPassword +
 * ", dateOfBirthOfPerson=" + dateOfBirthOfPerson + "]"; }
 * 
 * @Override public int hashCode() { final int prime = 31; int result = 1;
 * result = prime * result + ((dateOfBirthOfPerson == null) ? 0 :
 * dateOfBirthOfPerson.hashCode()); result = prime * result + ((personEmailId ==
 * null) ? 0 : personEmailId.hashCode()); result = prime * result +
 * ((personFirstName == null) ? 0 : personFirstName.hashCode()); result = prime
 * * result + ((personLastName == null) ? 0 : personLastName.hashCode()); result
 * = prime * result + ((personPassword == null) ? 0 :
 * personPassword.hashCode()); result = prime * result + ((repeatPersonPassword
 * == null) ? 0 : repeatPersonPassword.hashCode()); result = prime * result +
 * ((securityAnswer == null) ? 0 : securityAnswer.hashCode()); return result; }
 * 
 * @Override public boolean equals(Object obj) { if (this == obj) return true;
 * if (obj == null) return false; if (getClass() != obj.getClass()) return
 * false; Persons other = (Persons) obj; if (dateOfBirthOfPerson == null) { if
 * (other.dateOfBirthOfPerson != null) return false; } else if
 * (!dateOfBirthOfPerson.equals(other.dateOfBirthOfPerson)) return false; if
 * (personEmailId == null) { if (other.personEmailId != null) return false; }
 * else if (!personEmailId.equals(other.personEmailId)) return false; if
 * (personFirstName == null) { if (other.personFirstName != null) return false;
 * } else if (!personFirstName.equals(other.personFirstName)) return false; if
 * (personLastName == null) { if (other.personLastName != null) return false; }
 * else if (!personLastName.equals(other.personLastName)) return false; if
 * (personPassword == null) { if (other.personPassword != null) return false; }
 * else if (!personPassword.equals(other.personPassword)) return false; if
 * (repeatPersonPassword == null) { if (other.repeatPersonPassword != null)
 * return false; } else if
 * (!repeatPersonPassword.equals(other.repeatPersonPassword)) return false; if
 * (securityAnswer == null) { if (other.securityAnswer != null) return false; }
 * else if (!securityAnswer.equals(other.securityAnswer)) return false; return
 * true; }
 * 
 * 
 * 
 * }
 */

package com.cg.capbook.beans;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
@Entity
public class Persons {
	@Id
	@NotEmpty(message="Enter Email")
	@Pattern(regexp="^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{1,3})$",message="Enter Valid Email")
	private String personEmailId;
	@NotEmpty(message="Enter First Name")
	@Pattern(regexp="^[a-zA-Z]{2,}$",message="Enter Valid First Name")
	private String personFirstName;
	@NotEmpty(message="Enter Last Name")
	@Pattern(regexp="^[a-zA-Z]{2,}$",message="Enter Valid Last Name")
	private String personLastName;
	@NotEmpty(message="Enter Password")
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$",message="Enter Valid Password")
	private String personPassword;
	@NotEmpty(message="Enter Security Password")
	private String securityAnswer;
	@NotEmpty(message="Enter Password repeat")
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$",message="Enter Valid Password")
	private String repeatPersonPassword;
	@NotEmpty(message="Enter Date")
	private String dateOfBirthOfPerson;
	private String photo;

	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getPersonFirstName() {
		return personFirstName;
	}
	public void setPersonFirstName(String personFirstName) {
		this.personFirstName = personFirstName;
	}
	public String getPersonLastName() {
		return personLastName;
	}
	public void setPersonLastName(String personLastName) {
		this.personLastName = personLastName;
	}
	public String getPersonEmailId() {
		return personEmailId;
	}
	public void setPersonEmailId(String personEmailId) {
		this.personEmailId = personEmailId;
	}
	public String getPersonPassword() {
		return personPassword;
	}
	public void setPersonPassword(String personPassword) {
		this.personPassword = personPassword;
	}
	public String getRepeatPersonPassword() {
		return repeatPersonPassword;
	}
	public void setRepeatPersonPassword(String repeatPersonPassword) {
		this.repeatPersonPassword = repeatPersonPassword;
	}
	public String getDateOfBirthOfPerson() {
		return dateOfBirthOfPerson;
	}
	public void setDateOfBirthOfPerson(String dateOfBirthOfPerson) {
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public Persons(
			@NotEmpty(message = "Enter Email") @Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{1,3})$", message = "Enter Valid Email") String personEmailId,
			@NotEmpty(message = "Enter First Name") @Pattern(regexp = "^[a-zA-Z]{2,}$", message = "Enter Valid First Name") String personFirstName,
			@NotEmpty(message = "Enter Last Name") @Pattern(regexp = "^[a-zA-Z]{2,}$", message = "Enter Valid Last Name") String personLastName,
			@NotEmpty(message = "Enter Password") @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$", message = "Enter Valid Password") String personPassword,
			@NotEmpty(message = "Enter Security Password") String securityAnswer,
			@NotEmpty(message = "Enter Password repeat") @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$", message = "Enter Valid Password") String repeatPersonPassword,
			@NotEmpty(message = "Enter Date") String dateOfBirthOfPerson) {
		super();
		this.personEmailId = personEmailId;
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
		this.personPassword = personPassword;
		this.securityAnswer = securityAnswer;
		this.repeatPersonPassword = repeatPersonPassword;
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
	}
	public Persons(
			@NotEmpty(message = "Enter First Name") @Pattern(regexp = "^[a-zA-Z]{2,}$", message = "Enter Valid First Name") String personFirstName,
			@NotEmpty(message = "Enter Last Name") @Pattern(regexp = "^[a-zA-Z]{2,}$", message = "Enter Valid Last Name") String personLastName,
			@NotEmpty(message = "Enter Password") @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$", message = "Enter Valid Password") String personPassword,
			@NotEmpty(message = "Enter Security Password") String securityAnswer,
			@NotEmpty(message = "Enter Password repeat") @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$", message = "Enter Valid Password") String repeatPersonPassword,
			@NotEmpty(message = "Enter Date") String dateOfBirthOfPerson) {
		super();
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
		this.personPassword = personPassword;
		this.securityAnswer = securityAnswer;
		this.repeatPersonPassword = repeatPersonPassword;
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
	}
	public Persons() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateOfBirthOfPerson == null) ? 0 : dateOfBirthOfPerson.hashCode());
		result = prime * result + ((personEmailId == null) ? 0 : personEmailId.hashCode());
		result = prime * result + ((personFirstName == null) ? 0 : personFirstName.hashCode());
		result = prime * result + ((personLastName == null) ? 0 : personLastName.hashCode());
		result = prime * result + ((personPassword == null) ? 0 : personPassword.hashCode());
		result = prime * result + ((photo == null) ? 0 : photo.hashCode());
		result = prime * result + ((repeatPersonPassword == null) ? 0 : repeatPersonPassword.hashCode());
		result = prime * result + ((securityAnswer == null) ? 0 : securityAnswer.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persons other = (Persons) obj;
		if (dateOfBirthOfPerson == null) {
			if (other.dateOfBirthOfPerson != null)
				return false;
		} else if (!dateOfBirthOfPerson.equals(other.dateOfBirthOfPerson))
			return false;
		if (personEmailId == null) {
			if (other.personEmailId != null)
				return false;
		} else if (!personEmailId.equals(other.personEmailId))
			return false;
		if (personFirstName == null) {
			if (other.personFirstName != null)
				return false;
		} else if (!personFirstName.equals(other.personFirstName))
			return false;
		if (personLastName == null) {
			if (other.personLastName != null)
				return false;
		} else if (!personLastName.equals(other.personLastName))
			return false;
		if (personPassword == null) {
			if (other.personPassword != null)
				return false;
		} else if (!personPassword.equals(other.personPassword))
			return false;
		if (photo == null) {
			if (other.photo != null)
				return false;
		} else if (!photo.equals(other.photo))
			return false;
		if (repeatPersonPassword == null) {
			if (other.repeatPersonPassword != null)
				return false;
		} else if (!repeatPersonPassword.equals(other.repeatPersonPassword))
			return false;
		if (securityAnswer == null) {
			if (other.securityAnswer != null)
				return false;
		} else if (!securityAnswer.equals(other.securityAnswer))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Persons [personEmailId=" + personEmailId + ", personFirstName=" + personFirstName + ", personLastName="
				+ personLastName + ", personPassword=" + personPassword + ", securityAnswer=" + securityAnswer
				+ ", repeatPersonPassword=" + repeatPersonPassword + ", dateOfBirthOfPerson=" + dateOfBirthOfPerson
				+ "]";
	}

	
	
}
