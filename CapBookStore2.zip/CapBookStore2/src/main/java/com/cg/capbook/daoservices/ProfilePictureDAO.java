package com.cg.capbook.daoservices;

import java.io.IOException;

import javax.sql.DataSource;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.multipart.MultipartFile;

public interface ProfilePictureDAO{	
	public int inserRecords(MultipartFile photo) throws IOException;
}
